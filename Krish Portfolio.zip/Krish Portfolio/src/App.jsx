import React from 'react';
import Portfolio from './Portfolio.jsx';

export default function App() {
  return <Portfolio />;
}
