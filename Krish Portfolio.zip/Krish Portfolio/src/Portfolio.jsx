import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useMotionValue, useSpring, useTransform } from 'framer-motion';
import { 
  ArrowRight, Play, CheckCircle, BarChart3, 
  Users, Layers, Instagram, Youtube, Mail, 
  Menu, X, Calendar, Download, ExternalLink,
  ChevronRight, TrendingUp, Search, PenTool, 
  Video, Rocket, MapPin, FileText, Smartphone,
  MonitorPlay, Sparkles, Loader2, Copy, Linkedin, Twitter,
  Zap, Globe, Cpu, Lock, Edit3, Trash2, Plus, Save, LogOut,
  BookOpen, ThumbsUp, Send, Briefcase, UserPlus
} from 'lucide-react';

// --- FIREBASE IMPORTS ---
import { initializeApp } from 'firebase/app';
import { 
  getFirestore, collection, getDocs, addDoc, 
  updateDoc, deleteDoc, doc
} from 'firebase/firestore';
import { getAuth, signInAnonymously, signInWithCustomToken, onAuthStateChanged } from 'firebase/auth';

// --- FIREBASE SETUP (SAFE MODE) ---
let auth = null;
let db = null;
let appId = 'krish-portfolio-v1';
let isFirebaseReady = false;

try {
  // These globals can be injected by your hosting platform if you want to use real Firebase.
  if (typeof window !== 'undefined' && typeof window.__firebase_config !== 'undefined') {
    const firebaseConfig = JSON.parse(window.__firebase_config);
    const app = initializeApp(firebaseConfig);
    auth = getAuth(app);
    db = getFirestore(app);
    appId = typeof window.__app_id !== 'undefined' ? window.__app_id : 'krish-portfolio-v1';
    isFirebaseReady = true;
  } else {
    console.warn("Firebase config not found. Running in Demo Mode (local defaults only).");
  }
} catch (error) {
  console.warn("Firebase init failed. Running in Demo Mode.", error);
}

// --- CONFIGURATION ---
// 📸 PASTE YOUR LINKEDIN PHOTO URL HERE
const PROFILE_IMG = "https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=400&h=400&fit=crop&q=80"; 

// --- CONSTANTS & DEFAULTS ---
const NAV_LINKS = [
  { id: 'home', label: 'Home' },
  { id: 'work', label: 'Work' },
  { id: 'services', label: 'Services & Exp' },
  { id: 'ai-demo', label: 'AI Demo ✨' },
  { id: 'contact', label: 'Contact' }
];

const DEFAULTS = {
  metrics: [
    { label: "Active Channels", value: "4", icon: "TrendingUp" },
    { label: "Content Formats", value: "4", icon: "Layers" },
    { label: "Growth Focus", value: "100%", icon: "BarChart3" }
  ],
  services: [
    { title: "Monthly Content Calendars", desc: "Developing comprehensive content strategies with seasonal themes.", icon: "Calendar" },
    { title: "Copywriting Excellence", desc: "Crafting compelling captions, video descriptions, and SEO-optimized copy.", icon: "FileText" },
    { title: "Growth Strategy", desc: "Leveraging analytics, trend analysis, and performance metrics.", icon: "TrendingUp" }
  ],
  portfolio: [
    { 
      client: "Gen S Life", 
      platform: "YouTube", 
      title: "Let's Walk Campaign", 
      desc: "Strategic video campaign encouraging community movement. Managed end-to-end production and narrative flow.", 
      stats: "Community Growth", 
      image: "https://images.unsplash.com/photo-1536240478700-b869070f9279?auto=format&fit=crop&q=80&w=1000", 
      category: "Campaigns",
      link: "https://www.youtube.com/channel/UCz2WAWq4J2UrCR7TURQ6okQ"
    },
    { 
      client: "Gen S Life", 
      platform: "YouTube", 
      title: "Gift Ideas (Independence Day)", 
      desc: "Seasonal content special: 'Gift ideas for your Parents'. Scripted for emotional connection and high viewer retention.", 
      stats: "Holiday Special", 
      image: "https://images.unsplash.com/photo-1513201099705-a9746e1e201f?auto=format&fit=crop&q=80&w=1000", 
      category: "Campaigns",
      link: "https://www.youtube.com/channel/UCz2WAWq4J2UrCR7TURQ6okQ"
    },
    { client: "Gen S Life", platform: "YouTube", title: "Channel Management", desc: "Welcome to My Gen S Life. A Channel for the Young at Heart. Building a digital bridge between generations.", stats: "Channel Growth", image: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&q=80&w=1000", category: "YouTube", link: "https://www.youtube.com/channel/UCz2WAWq4J2UrCR7TURQ6okQ" },
    { client: "Ek Sur", platform: "YouTube", title: "With Prasad Sangameshwaram", desc: "Where Music Becomes Prayer. Managing the 'Ek Sur' spiritual concert series channel.", stats: "Spiritual Niche", image: "https://images.unsplash.com/photo-1516280440614-6697288d5d38?auto=format&fit=crop&q=80&w=1000", category: "YouTube", link: "https://www.youtube.com/channel/UCXmnZMnVNXuMHfmKxLxPPeA" },
    { client: "Gen S Life Official", platform: "Instagram", title: "IG Strategy & Community", desc: "Managing comprehensive Instagram strategy with focus on community engagement.", stats: "@genslifeofficial", image: "https://images.unsplash.com/photo-1611162616475-46b635cb6868?auto=format&fit=crop&q=80&w=1000", category: "Instagram", link: "https://www.instagram.com/genslifeofficial/" },
    { client: "Ek Sur Devotional", platform: "Instagram", title: "Spiritual Community", desc: "Curating devotional music content that builds spiritual community through thoughtful captions and engagement.", stats: "@ek_sur_", image: "https://images.unsplash.com/photo-1611162618071-b39a2ec055fb?auto=format&fit=crop&q=80&w=1000", category: "Instagram", link: "https://www.instagram.com/ek_sur_/" }
  ],
  experience: [
    { 
      role: "Jr. Content Executive & Manager", 
      company: "GenSxty Tribe", 
      period: "Apr 2025 - Present", 
      desc: "Leading content strategies and managing end-to-end flow for YouTube & Instagram. Coordinating online/offline events and team leadership." 
    },
    { 
      role: "Content Researcher & Developer", 
      company: "GenSxty Tribe", 
      period: "Mar 2024 - Mar 2025", 
      desc: "Researched and developed engaging content. Led pre-production for content series and optimized digital assets for audience engagement." 
    },
    { 
      role: "Founder's Office & Copywriter", 
      company: "Ep.Log Media", 
      period: "Dec 2023 - Feb 2024", 
      desc: "Created compelling marketing copy and managed post-production workflows. Assisted in strategic decision-making for innovative content." 
    }
  ]
};

const ICON_MAP = {
  TrendingUp: <TrendingUp className="w-6 h-6 text-emerald-400" />,
  Layers: <Layers className="w-6 h-6 text-emerald-400" />,
  BarChart3: <BarChart3 className="w-6 h-6 text-emerald-400" />,
  Calendar: <Calendar className="w-8 h-8 text-amber-500" />,
  FileText: <FileText className="w-8 h-8 text-amber-500" />,
  Users: <Users className="w-8 h-8 text-amber-500" />,
  Search: <Search className="w-8 h-8 text-amber-500" />,
  PenTool: <PenTool className="w-8 h-8 text-amber-500" />
};

// --- SIMPLE FRONTEND AI DEMO (NO BACKEND NEEDED) ---
async function generateRepurposingPlan(topic) {
  const cleaned = topic.trim();
  const safeTopic = cleaned || "your content";

  return {
    hooks: [
      `You're losing views on ${safeTopic} because of this one mistake…`,
      `If you're serious about ${safeTopic}, watch this before you post again.`,
      `Stop posting random clips. Do this with ${safeTopic} instead.`,
      `The 3–step shortcut to turning ${safeTopic} into daily content.`
    ],
    linkedin:
`Everyone wants more views.
Very few are repurposing properly.

Here’s how I’d turn one video about "${safeTopic}" into a full month of content:

• 3–5 short Reels (hooks tested on day 1–3)
• 1 LinkedIn post breaking down the process
• 1 Twitter thread with the key insights
• 5–7 carousels reusing the same talking points
• 1 weekly recap post with performance learnings

The content isn’t the problem.
The system is.

Once you fix your system, one good video can power your entire content calendar.

If you’d like a repurposing system tailored to your niche, reply “SYSTEM” and I’ll send you a framework.`,
    twitter: [
      `"${safeTopic}" content isn’t dying.  
Random content is.`,
      `Most creators:
- Record once
- Post once
- Hope it works

Operators:
- Record once
- Slice it 10+ ways
- Test hooks
- Double down on what works.`,
      `One video on "${safeTopic}" can become:
- 5 Reels
- 1 LinkedIn post
- 1 Twitter thread
- 3 carousels
- 1 newsletter issue

It's not about creating more.
It's about multiplying what works.`,
      `If you don't have a repurposing system yet, you don't have a content problem.

You have a process problem.`,
      `Build a system once → reuse it for every video.

That's how you scale without burning out.`
    ]
  };
}

// --- UTILS & HOOKS ---

const useSpotlight = () => {
  const divRef = useRef(null);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [opacity, setOpacity] = useState(0);

  const handleMouseMove = (e) => {
    if (!divRef.current) return;
    const rect = divRef.current.getBoundingClientRect();
    setPosition({ x: e.clientX - rect.left, y: e.clientY - rect.top });
  };

  return { divRef, position, opacity, handleMouseMove, 
           handleMouseEnter: () => setOpacity(1), 
           handleMouseLeave: () => setOpacity(0) };
};

const SpotlightCard = ({ children, className = "", onClick }) => {
  const { divRef, position, opacity, handleMouseMove, handleMouseEnter, handleMouseLeave } = useSpotlight();
  return (
    <motion.div
      ref={divRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onClick={onClick}
      className={`relative overflow-hidden rounded-[2rem] bg-slate-900/40 backdrop-blur-xl border border-white/5 transition-all duration-300 group ${onClick ? 'cursor-pointer' : ''} ${className}`}
      whileHover={{ scale: 1.02, y: -5 }}
    >
      <div className="pointer-events-none absolute -inset-px opacity-0 transition duration-300 group-hover:opacity-100 z-10"
        style={{ opacity, background: `radial-gradient(600px circle at ${position.x}px ${position.y}px, rgba(245, 158, 11, 0.15), transparent 40%)` }} />
      <div className="pointer-events-none absolute inset-0 opacity-0 transition duration-300 group-hover:opacity-100 z-10 border border-amber-500/30 rounded-[2rem]"
         style={{ maskImage: `radial-gradient(300px circle at ${position.x}px ${position.y}px, black, transparent)`, WebkitMaskImage: `radial-gradient(300px circle at ${position.x}px ${position.y}px, black, transparent)` }} />
      <div className="relative z-20 h-full">{children}</div>
    </motion.div>
  );
};

const SpotlightButton = ({ children, onClick, isActive, className = "" }) => {
  const { divRef, position, opacity, handleMouseMove, handleMouseEnter, handleMouseLeave } = useSpotlight();
  return (
    <button
      ref={divRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onClick={onClick}
      className={`relative px-5 py-2.5 rounded-full text-sm font-bold transition-all duration-300 overflow-hidden group ${isActive ? 'text-slate-900 bg-white' : 'text-slate-400 hover:text-white'} ${className}`}
      type="button"
    >
      <div className="pointer-events-none absolute -inset-px opacity-0 transition duration-300 group-hover:opacity-100"
        style={{ opacity, background: `radial-gradient(100px circle at ${position.x}px ${position.y}px, rgba(255, 255, 255, 0.2), transparent 50%)` }} />
      <span className="relative z-10">{children}</span>
    </button>
  );
};

// Interactive Magnetic Button
const InteractiveButton = ({ children, onClick, className = "" }) => {
  const ref = useRef(null);
  const [position, setPosition] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e) => {
    if (!ref.current) return;
    const { clientX, clientY } = e;
    const { left, top, width, height } = ref.current.getBoundingClientRect();
    const x = (clientX - (left + width / 2)) * 0.3;
    const y = (clientY - (top + height / 2)) * 0.3;
    setPosition({ x, y });
  };

  const handleMouseLeave = () => {
    setPosition({ x: 0, y: 0 });
  };

  return (
    <motion.button
      ref={ref}
      type="button"
      onClick={onClick}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      animate={{ x: position.x, y: position.y }}
      transition={{ type: "spring", stiffness: 150, damping: 15, mass: 0.1 }}
      className={`relative overflow-hidden group bg-gradient-to-r from-amber-500 to-orange-600 text-slate-900 font-bold rounded-full shadow-lg shadow-amber-500/20 ${className}`}
    >
      <div className="absolute inset-0 -translate-x-full group-hover:animate-[shimmer_1.5s_infinite] bg-gradient-to-r from-transparent via-white/30 to-transparent z-10" />
      <span className="relative z-20 flex items-center justify-center gap-2 px-8 py-4">
        {children}
      </span>
    </motion.button>
  );
};

const LoadingScreen = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);
  const [stageIndex, setStageIndex] = useState(0);
  
  const stages = [
    { icon: <BookOpen size={64} className="text-amber-500" />, label: "Drafting Idea...", sub: "Conceptualizing the next big thing" },
    { icon: <FileText size={64} className="text-blue-400" />, label: "Scripting...", sub: "Structuring for maximum retention" },
    { icon: <Smartphone size={64} className="text-emerald-400" />, label: "Recording...", sub: "Lights, camera, action" },
    { icon: <ThumbsUp size={64} className="text-pink-500" />, label: "Engagement!", sub: "Delivering results" }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(onComplete, 800); 
          return 100;
        }
        return prev + 1;
      });
    }, 35);

    return () => clearInterval(timer);
  }, [onComplete]);

  useEffect(() => {
    if (progress < 25) setStageIndex(0);
    else if (progress < 50) setStageIndex(1);
    else if (progress < 75) setStageIndex(2);
    else setStageIndex(3);
  }, [progress]);

  return (
    <motion.div 
      className="fixed inset-0 z-[100] bg-slate-950 flex items-center justify-center overflow-hidden"
      exit={{ opacity: 0, y: -50 }}
      transition={{ duration: 0.8, ease: [0.76, 0, 0.24, 1] }}
    >
      <div className="absolute inset-0 opacity-20" style={{ backgroundImage: `radial-gradient(circle at 1px 1px, rgba(255,255,255,0.15) 1px, transparent 0)`, backgroundSize: '40px 40px' }} />
      
      <div className="relative z-10 flex flex-col items-center text-center px-6">
        <div className="h-32 flex items-center justify-center mb-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={stageIndex}
              initial={{ opacity: 0, scale: 0.8, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: -20 }}
              transition={{ duration: 0.3 }}
              className="p-6 bg-slate-900/50 rounded-full border border-white/10 shadow-2xl backdrop-blur-md relative"
            >
              {stages[stageIndex].icon}
              <div className="absolute inset-0 bg-white/5 rounded-full blur-xl -z-10"></div>
            </motion.div>
          </AnimatePresence>
        </div>

        <div className="space-y-2 mb-8 h-16">
          <motion.h2 
            key={`h-${stageIndex}`}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-3xl font-bold text-white tracking-tight"
          >
            {stages[stageIndex].label}
          </motion.h2>
          <motion.p
            key={`p-${stageIndex}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-slate-400 font-mono text-sm"
          >
            {stages[stageIndex].sub}
          </motion.p>
        </div>

        <div className="w-64 h-2 bg-slate-800 rounded-full overflow-hidden relative">
          <motion.div 
            className="absolute top-0 left-0 h-full bg-gradient-to-r from-amber-500 to-emerald-500"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="mt-4 font-mono text-slate-500 text-xs">{progress}% PROCESSED</div>
      </div>
    </motion.div>
  );
};

// --- ADMIN & CMS COMPONENTS ---

const AdminLoginModal = ({ isOpen, onClose, onLogin }) => {
  const [pin, setPin] = useState('');
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-white/10 p-8 rounded-3xl w-full max-w-sm text-center shadow-2xl">
        <Lock className="w-12 h-12 text-amber-500 mx-auto mb-4" />
        <h3 className="text-2xl font-bold text-white mb-2">Admin Access</h3>
        <p className="text-slate-400 mb-6 text-sm">Enter security PIN to manage content.</p>
        <input 
          type="password" 
          maxLength={4}
          value={pin}
          onChange={(e) => setPin(e.target.value)}
          className="w-full bg-slate-800 border border-white/10 rounded-xl p-4 text-center text-2xl tracking-[1em] text-white focus:border-amber-500 outline-none mb-6 font-mono"
          placeholder="••••"
        />
        <div className="flex gap-3">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-3 rounded-xl text-slate-400 hover:bg-slate-800 transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => onLogin(pin)}
            className="flex-1 py-3 rounded-xl bg-amber-500 text-slate-900 font-bold hover:bg-amber-400 transition-colors"
          >
            Unlock
          </button>
        </div>
      </div>
    </div>
  );
};

// New Contact Modal for "Let's Talk" Button
const ContactModal = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-6">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-slate-900 border border-white/10 p-8 md:p-12 rounded-[2rem] w-full max-w-xl shadow-2xl relative"
      >
        <button 
          onClick={onClose}
          type="button"
          className="absolute top-6 right-6 p-2 bg-slate-800 rounded-full text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
        >
          <X size={20} />
        </button>
        
        <div className="text-center mb-8">
          <h3 className="text-3xl font-bold text-white mb-2">Quick Inquiry</h3>
          <p className="text-slate-400">Tell me about your project. I'll respond within 24hrs.</p>
        </div>

        <form
          className="space-y-5"
          onSubmit={(e) => {
            e.preventDefault();
            onClose();
          }}
        >
          <div className="grid grid-cols-2 gap-4">
             <div className="space-y-1">
              <label className="text-xs font-bold text-amber-500 uppercase tracking-widest ml-1">Name</label>
              <input type="text" className="w-full bg-slate-950/50 border border-white/10 rounded-xl p-3 text-white focus:border-amber-500 outline-none transition-all" placeholder="Name" />
             </div>
             <div className="space-y-1">
              <label className="text-xs font-bold text-amber-500 uppercase tracking-widest ml-1">Email</label>
              <input type="email" className="w-full bg-slate-950/50 border border-white/10 rounded-xl p-3 text-white focus:border-amber-500 outline-none transition-all" placeholder="Email" />
             </div>
          </div>
          <div className="space-y-1">
            <label className="text-xs font-bold text-amber-500 uppercase tracking-widest ml-1">Project Details</label>
            <textarea rows={4} className="w-full bg-slate-950/50 border border-white/10 rounded-xl p-3 text-white focus:border-amber-500 outline-none transition-all resize-none" placeholder="How can I help you grow?" />
          </div>
          <button
            type="submit"
            className="w-full py-4 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 text-slate-900 font-bold text-lg hover:scale-[1.02] active:scale-[0.98] transition-transform flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20"
          >
            <Send size={20} /> Send Request
          </button>
        </form>
      </motion.div>
    </div>
  );
};

const DashboardItem = ({ item, onDelete, onEdit }) => (
  <div className="bg-slate-800/50 border border-white/5 p-4 rounded-xl flex justify-between items-center group hover:border-amber-500/30 transition-colors">
    <div>
      <div className="font-bold text-white">{String(item.title || item.client || item.role || item.label || 'Untitled')}</div>
      <div className="text-xs text-slate-400 truncate max-w-[200px]">{String(item.desc || item.company || item.platform || item.value || '')}</div>
    </div>
    <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
      <button
        type="button"
        onClick={() => onEdit(item)}
        className="p-2 hover:bg-slate-700 rounded-lg text-slate-300 hover:text-amber-500"
      >
        <Edit3 size={16} />
      </button>
      <button
        type="button"
        onClick={() => onDelete(item.id)}
        className="p-2 hover:bg-slate-700 rounded-lg text-slate-300 hover:text-red-500"
      >
        <Trash2 size={16} />
      </button>
    </div>
  </div>
);

const Dashboard = ({ data, onUpdate, collectionName, title }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [currentItem, setCurrentItem] = useState(null);

  const handleSave = async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const newItem = Object.fromEntries(formData.entries());
    
    if (currentItem?.id) {
      await onUpdate(collectionName, { ...currentItem, ...newItem }, 'update');
    } else {
      await onUpdate(collectionName, newItem, 'add');
    }
    setIsEditing(false);
    setCurrentItem(null);
  };

  return (
    <div className="bg-slate-900/40 backdrop-blur-md border border-white/5 rounded-3xl p-8 mb-8">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-2xl font-bold text-white">{title}</h3>
        <button
          type="button"
          onClick={() => { setCurrentItem({}); setIsEditing(true); }}
          className="flex items-center gap-2 px-4 py-2 bg-amber-500/10 text-amber-500 rounded-xl hover:bg-amber-500 hover:text-slate-900 transition-all font-bold text-sm"
        >
          <Plus size={16} /> Add New
        </button>
      </div>

      <div className="grid gap-4">
        {data.map((item, i) => (
          <DashboardItem 
            key={item.id || i} 
            item={item} 
            onDelete={(id) => onUpdate(collectionName, { id }, 'delete')}
            onEdit={(item) => { setCurrentItem(item); setIsEditing(true); }}
          />
        ))}
      </div>

      {isEditing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
          <form onSubmit={handleSave} className="bg-slate-900 border border-white/10 p-8 rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <h4 className="text-xl font-bold text-white mb-6">{currentItem?.id ? 'Edit Item' : 'Add New Item'}</h4>
            <div className="space-y-4">
              {['title', 'client', 'role', 'company', 'period', 'desc', 'platform', 'stats', 'label', 'value', 'image', 'category', 'icon', 'link'].map(field => (
                (collectionName === 'metrics' && ['label','value','icon'].includes(field)) ||
                (collectionName === 'services' && ['title','desc','icon'].includes(field)) ||
                (collectionName === 'experience' && ['role','company','period','desc'].includes(field)) ||
                (collectionName === 'portfolio' && !['label','value','role','company','period'].includes(field)) ? (
                  <div key={field}>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">{field}</label>
                    <input 
                      name={field}
                      defaultValue={String(currentItem?.[field] || '')}
                      className="w-full bg-slate-800 border border-white/10 rounded-xl p-3 text-white focus:border-amber-500 outline-none"
                    />
                  </div>
                ) : null
              ))}
            </div>
            <div className="flex gap-3 mt-8">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="flex-1 py-3 rounded-xl text-slate-400 hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 py-3 rounded-xl bg-amber-500 text-slate-900 font-bold hover:bg-amber-400"
              >
                Save
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

// --- MAIN VIEWS ---

const HomeView = ({ setView, metrics, mouseX, mouseY, onLetsTalk }) => {
  const x = useSpring(mouseX, { stiffness: 100, damping: 30 });
  const y = useSpring(mouseY, { stiffness: 100, damping: 30 });

  const viewportWidth = typeof window !== 'undefined' ? window.innerWidth : 1200;
  const viewportHeight = typeof window !== 'undefined' ? window.innerHeight : 800;
  
  const rotateX = useTransform(y, [0, viewportHeight], [5, -5]);
  const rotateY = useTransform(x, [0, viewportWidth], [-5, 5]);

  return (
    <div className="space-y-32 pb-32">
      {/* HERO SECTION */}
      <section className="relative min-h-[90vh] flex items-center pt-24 px-6 perspective-1000">
        <div className="max-w-7xl mx-auto w-full relative z-10 grid md:grid-cols-2 gap-16 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            style={{ rotateX, rotateY, z: 100, perspective: 1000 }}
            transition={{ duration: 1, ease: "easeOut" }}
          >
            <div className="inline-flex items-center gap-3 px-4 py-2 rounded-full bg-slate-800/40 backdrop-blur-xl border border-white/10 text-amber-400 text-sm font-bold uppercase tracking-wider mb-8 shadow-lg shadow-black/20">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-amber-500"></span>
              </span>
              Available for New Clients
            </div>
            <h1 className="text-6xl md:text-8xl font-black leading-[1.1] mb-8 tracking-tight">
              Turn one video into a <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-orange-500 to-amber-400 animate-gradient-x">month of growth.</span>
            </h1>
            <p className="text-xl md:text-2xl text-slate-300 mb-12 max-w-lg leading-relaxed font-light">
              Mumbai-based Social Media Manager. I repurpose long-form content into high-performing shorts, reels, and posts.
            </p>
            <div className="flex flex-col sm:flex-row gap-6">
              <InteractiveButton onClick={onLetsTalk}>
                Start Project ⚡
              </InteractiveButton>
              <button
                type="button"
                onClick={() => setView('work')}
                className="px-8 py-4 rounded-2xl font-bold bg-slate-800/40 border border-white/10 text-slate-200 hover:bg-slate-800/60 hover:border-amber-500/30 transition-all"
              >
                View Portfolio
              </button>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="relative hidden md:block"
            style={{ 
              x: useTransform(x, value => (value - viewportWidth / 2) * -0.02), 
              y: useTransform(y, value => (value - viewportHeight / 2) * -0.02),
              rotateX: useTransform(y, [0, viewportHeight], [-2, 2]),
              rotateY: useTransform(x, [0, viewportWidth], [2, -2])
            }}
          >
            <div className="relative aspect-square">
              <div className="absolute inset-0 bg-gradient-to-br from-slate-800/30 to-slate-900/30 backdrop-blur-2xl rounded-[3rem] border border-white/10 shadow-2xl flex items-center justify-center overflow-hidden group">
                <div className="absolute inset-0 bg-gradient-to-br from-amber-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
                
                {/* LINKEDIN PROFILE CARD */}
                <div className="flex flex-col items-center p-8 relative z-10 cursor-pointer group/profile w-full h-full justify-center">
                  <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-r from-slate-700 to-slate-800 rounded-t-[3rem]"></div>
                  
                  <a 
                    href="https://www.linkedin.com/in/krrish-patil-8619a9275/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="relative flex flex-col items-center w-full z-20"
                  >
                    <div className="relative mb-4 mt-8 group-hover/profile:scale-105 transition-transform duration-500">
                      <div className="w-32 h-32 rounded-full p-1 bg-slate-900 shadow-2xl">
                        <img 
                          src={PROFILE_IMG} 
                          alt="Krish Patil" 
                          className="w-full h-full object-cover rounded-full border-4 border-slate-900"
                        />
                      </div>
                      <div className="absolute bottom-2 right-2 bg-[#0077b5] p-1.5 rounded-full border-4 border-slate-900 shadow-lg">
                        <Linkedin size={20} className="text-white fill-white" />
                      </div>
                    </div>
                    
                    <div className="text-center space-y-1">
                      <h3 className="text-2xl font-bold text-white group-hover/profile:text-blue-400 transition-colors flex items-center justify-center gap-2">
                        Krish Patil 
                        <span className="text-slate-400 text-sm font-normal">(He/Him)</span>
                      </h3>
                      <p className="text-slate-300 text-sm font-medium max-w-[250px] mx-auto leading-snug">
                        Social Media Manager | Content Strategist | YouTube Growth
                      </p>
                      <div className="flex items-center justify-center gap-1 text-slate-500 text-xs pt-1">
                        <MapPin size={12} />
                        <span>Mumbai, Maharashtra, India</span>
                      </div>
                    </div>

                    <div className="mt-6 w-full max-w-[200px]">
                      <div className="w-full py-2 rounded-full bg-[#0a66c2] hover:bg-[#004182] text-white font-bold text-sm transition-colors flex items-center justify-center gap-2 shadow-lg">
                        <UserPlus size={16} />
                        Connect
                      </div>
                    </div>
                  </a>
                </div>

                {/* Orbiting Icons */}
                <motion.div 
                  animate={{ y: [0, -15, 0], x: [0, 5, 0] }} 
                  transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }} 
                  className="absolute top-24 right-8 bg-slate-900/90 backdrop-blur-xl p-4 rounded-2xl border border-white/10 shadow-2xl z-30"
                >
                  <Instagram className="text-pink-500 w-6 h-6" />
                </motion.div>
                <motion.div 
                  animate={{ y: [0, 20, 0], x: [0, -5, 0] }} 
                  transition={{ repeat: Infinity, duration: 5, ease: "easeInOut" }} 
                  className="absolute bottom-24 left-8 bg-slate-900/90 backdrop-blur-xl p-4 rounded-2xl border border-white/10 shadow-2xl z-30"
                >
                  <Youtube className="text-red-500 w-6 h-6" />
                </motion.div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* METRICS */}
      <section className="max-w-7xl mx-auto px-6">
        <div className="bg-slate-900/40 backdrop-blur-xl border border-white/5 rounded-[3rem] py-16 px-8 md:px-16 shadow-2xl relative overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 relative z-10">
            {metrics.map((m, i) => (
              <div key={m.id || i} className="text-center">
                <div className="flex justify-center mb-4 transform hover:scale-110 transition-transform duration-300 bg-emerald-500/10 w-16 h-16 rounded-2xl items-center mx-auto border border-emerald-500/20">
                  {ICON_MAP[m.icon] || <TrendingUp className="w-6 h-6 text-emerald-400" />}
                </div>
                <div className="text-5xl md:text-6xl font-black font-mono text-transparent bg-clip-text bg-gradient-to-b from-white to-slate-400 mb-3 tracking-tighter">{String(m.value)}</div>
                <div className="text-emerald-400 font-bold uppercase tracking-widest text-sm">{String(m.label)}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

const ServicesView = ({ services, experience }) => (
  <div className="pt-36 pb-24 max-w-7xl mx-auto px-6 min-h-screen">
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
       <h1 className="text-6xl font-bold mb-8 text-transparent bg-clip-text bg-gradient-to-r from-white to-slate-400">Services & Experience</h1>
       
       {/* SERVICES SECTION */}
       <div className="grid md:grid-cols-3 gap-8 mb-32">
         {services.map((s, i) => (
           <SpotlightCard key={s.id || i} className="p-8">
             <div className="w-16 h-16 bg-slate-800/50 rounded-2xl flex items-center justify-center text-amber-500 mb-8 border border-white/5">
               {ICON_MAP[s.icon] || <Calendar className="w-8 h-8 text-amber-500"/>}
             </div>
             <h3 className="text-2xl font-bold mb-4 text-white">{String(s.title)}</h3>
             <p className="text-slate-400 leading-relaxed text-lg">{String(s.desc)}</p>
           </SpotlightCard>
         ))}
       </div>

       {/* EXPERIENCE SECTION */}
       <div className="mb-32">
         <h2 className="text-4xl font-bold mb-12 text-white flex items-center gap-4">
           <div className="p-3 bg-slate-800 rounded-xl border border-white/10">
             <Briefcase className="w-8 h-8 text-emerald-400" />
           </div>
           Professional Experience
         </h2>
         <div className="grid gap-6">
           {experience.map((exp, i) => (
             <SpotlightCard key={exp.id || i} className="p-8">
               <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
                 <h3 className="text-2xl font-bold text-white">{String(exp.role)}</h3>
                 <span className="text-amber-500 font-mono text-sm bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20 w-fit mt-2 md:mt-0">
                   {String(exp.period)}
                 </span>
               </div>
               <div className="text-emerald-400 font-bold mb-4">{String(exp.company)}</div>
               <p className="text-slate-400 text-lg leading-relaxed">{String(exp.desc)}</p>
             </SpotlightCard>
           ))}
         </div>
       </div>
    </motion.div>
  </div>
);

const WorkView = ({ portfolio }) => {
  const [filter, setFilter] = useState('All');
  const categories = ['All', ...new Set(portfolio.map(p => p.category))];
  const filtered = filter === 'All' ? portfolio : portfolio.filter(p => p.category === filter);

  return (
    <div className="pt-36 pb-24 max-w-7xl mx-auto px-6 min-h-screen">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-6xl font-bold mb-8 text-white">Selected Work</h1>
        
        <div className="flex flex-wrap gap-4 mb-12">
          {categories.map(cat => (
            <button
              key={cat}
              type="button"
              onClick={() => setFilter(cat)}
              className={`px-6 py-2 rounded-full border transition-all ${filter === cat ? 'bg-amber-500 text-slate-900 border-amber-500' : 'text-slate-400 border-white/10'}`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="grid gap-12">
          {filtered.map((project, i) => (
            <SpotlightCard 
              key={project.id || i} 
              className="p-8 flex flex-col md:flex-row gap-10 group" 
              onClick={() => project.link && window.open(project.link, '_blank')}
            >
              <div className="w-full md:w-2/5 aspect-video rounded-3xl overflow-hidden relative shadow-2xl">
                <img src={project.image} alt={project.client} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
              </div>
              <div className="flex-1 py-2">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-3xl font-bold text-white mb-2 group-hover:text-amber-500 transition-colors">{String(project.client)}</h3>
                  {project.link && <ExternalLink className="text-slate-500 group-hover:text-white transition-colors" size={20} />}
                </div>
                <div className="text-emerald-400 font-mono text-sm font-bold mb-6 uppercase">{String(project.title)}</div>
                <p className="text-slate-300 mb-8 text-lg">{String(project.desc)}</p>
                <div className="inline-flex items-center gap-2 bg-slate-800 px-4 py-2 rounded-full text-sm text-slate-300 border border-white/10">
                  <Sparkles size={14} className="text-amber-500" /> {String(project.stats)}
                </div>
              </div>
            </SpotlightCard>
          ))}
        </div>
      </motion.div>
    </div>
  );
};

const AIToolView = () => {
  const [topic, setTopic] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleGenerate = async (e) => {
    e.preventDefault();
    if (!topic.trim()) return;

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const data = await generateRepurposingPlan(topic);
      setResult(data);
    } catch (err) {
      console.error(err);
      setError("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="pt-36 pb-24 max-w-7xl mx-auto px-6 min-h-screen">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-gradient-to-br from-amber-500/20 to-orange-500/20 rounded-2xl backdrop-blur-md border border-amber-500/30 shadow-lg shadow-amber-500/10">
            <Sparkles className="w-8 h-8 text-amber-400" />
          </div>
          <span className="text-amber-400 font-mono font-bold tracking-wider uppercase text-sm px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20">Live Demo</span>
        </div>
        
        <h1 className="text-6xl md:text-7xl font-bold mb-8 text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-200 to-slate-400">
          AI Content <br /><span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-orange-500">Repurposer</span>
        </h1>
        <p className="text-slate-300 text-xl max-w-2xl mb-12 leading-relaxed">
          Enter a video topic or rough idea below, and watch how I use AI to instantly generate a cross-platform content strategy.
        </p>

        {/* Input Section */}
        <div className="max-w-3xl mb-16 relative">
          <div className="absolute inset-0 bg-gradient-to-r from-amber-500/20 to-orange-500/20 blur-3xl -z-10 opacity-30 rounded-full" />
          <form onSubmit={handleGenerate} className="relative group">
            <textarea
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g. How to stay consistent with gym workouts..."
              className="w-full bg-slate-900/60 backdrop-blur-xl border border-white/10 rounded-3xl p-8 text-xl text-white placeholder:text-slate-500 focus:border-amber-500/50 focus:ring-2 focus:ring-amber-500/20 outline-none min-h-[200px] resize-none transition-all shadow-2xl"
            />
            <div className="absolute bottom-6 right-6">
              <button 
                type="submit"
                className={`bg-gradient-to-r from-amber-500 to-orange-600 text-slate-900 font-bold px-6 py-3 rounded-xl hover:scale-105 transition-transform flex items-center gap-2 ${loading ? "opacity-80 cursor-wait" : ""}`}
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" /> Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5" /> Generate Strategy
                  </>
                )}
              </button>
            </div>
          </form>
          {error && <p className="text-red-400 mt-4 bg-red-500/10 border border-red-500/20 p-4 rounded-xl">{error}</p>}
        </div>

        {/* Results Section */}
        {result && (
          <div className="grid md:grid-cols-3 gap-8">
            {/* Instagram Reels */}
            <SpotlightCard className="hover:border-pink-500/30 p-6">
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 bg-pink-500/10 rounded-xl border border-pink-500/20">
                  <Instagram className="w-6 h-6 text-pink-500" />
                </div>
                <h3 className="font-bold text-xl text-white">Reels Hooks</h3>
              </div>
              <ul className="space-y-4">
                {result.hooks.map((hook, i) => (
                  <li key={i} className="bg-slate-800/40 p-5 rounded-2xl border border-white/5 text-slate-200 leading-relaxed hover:bg-slate-800/60 transition-colors">
                    "{hook}"
                  </li>
                ))}
              </ul>
            </SpotlightCard>

            {/* LinkedIn Post */}
            <SpotlightCard className="hover:border-blue-500/30 p-6">
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 bg-blue-500/10 rounded-xl border border-blue-500/20">
                  <Linkedin className="w-6 h-6 text-blue-500" />
                </div>
                <h3 className="font-bold text-xl text-white">LinkedIn Draft</h3>
              </div>
              <div className="bg-slate-800/40 p-5 rounded-2xl border border-white/5 text-slate-200 whitespace-pre-wrap leading-relaxed h-[400px] overflow-y-auto custom-scrollbar hover:bg-slate-800/60 transition-colors">
                {result.linkedin}
              </div>
            </SpotlightCard>

            {/* Twitter Thread */}
            <SpotlightCard className="hover:border-sky-500/30 p-6">
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 bg-sky-500/10 rounded-xl border border-sky-500/20">
                  <Twitter className="w-6 h-6 text-sky-500" />
                </div>
                <h3 className="font-bold text-xl text-white">Thread Outline</h3>
              </div>
              <div className="space-y-4">
                {result.twitter.map((tweet, i) => (
                  <div key={i} className="bg-slate-800/40 p-5 rounded-2xl border border-white/5 text-slate-200 flex gap-4 hover:bg-slate-800/60 transition-colors">
                    <span className="text-slate-500 font-mono font-bold text-sm pt-1">{i+1}/</span>
                    <p className="leading-relaxed">{tweet}</p>
                  </div>
                ))}
              </div>
            </SpotlightCard>
          </div>
        )}
      </motion.div>
    </div>
  );
};

const ContactView = () => (
  <div className="pt-36 pb-24 max-w-7xl mx-auto px-6 min-h-screen">
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
      <h1 className="text-6xl font-bold mb-8 text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-200 to-slate-400">Let's work together</h1>
      <p className="text-slate-300 text-xl mb-16 leading-relaxed">
        Ready to scale your content operations? Fill out the form or reach out directly.
      </p>

      <div className="grid md:grid-cols-2 gap-12">
        {/* PREMIUM CONTACT FORM */}
        <SpotlightCard className="p-8 md:p-10">
          <form
            className="space-y-6"
            onSubmit={(e) => e.preventDefault()}
          >
            <div className="space-y-2">
              <label className="text-xs font-bold text-amber-500 uppercase tracking-widest ml-1">Name</label>
              <input 
                type="text" 
                className="w-full bg-slate-950/50 backdrop-blur-sm border border-white/10 rounded-xl p-4 text-white focus:border-amber-500/80 focus:bg-slate-900/80 outline-none transition-all text-lg shadow-inner" 
                placeholder="John Doe" 
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-amber-500 uppercase tracking-widest ml-1">Email</label>
              <input 
                type="email" 
                className="w-full bg-slate-950/50 backdrop-blur-sm border border-white/10 rounded-xl p-4 text-white focus:border-amber-500/80 focus:bg-slate-900/80 outline-none transition-all text-lg shadow-inner" 
                placeholder="john@company.com" 
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-amber-500 uppercase tracking-widest ml-1">Project Details</label>
              <textarea 
                rows={4} 
                className="w-full bg-slate-950/50 backdrop-blur-sm border border-white/10 rounded-xl p-4 text-white focus:border-amber-500/80 focus:bg-slate-900/80 outline-none transition-all text-lg resize-none shadow-inner" 
                placeholder="Tell me about your channel..." 
              />
            </div>
            <button
              type="submit"
              className="w-full py-4 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 text-slate-900 font-bold text-lg hover:scale-[1.02] active:scale-[0.98] transition-transform flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20"
            >
              <Send size={20} /> Send Inquiry
            </button>
          </form>
        </SpotlightCard>

        {/* DIRECT CONTACT CARD */}
        <SpotlightCard className="p-10 flex flex-col justify-center text-center h-full bg-slate-900/60">
          <div className="w-24 h-24 bg-slate-800/50 rounded-full flex items-center justify-center mx-auto mb-8 group-hover:scale-110 transition-transform duration-500 shadow-xl border border-white/5 overflow-hidden">
            <img 
              src={PROFILE_IMG} 
              alt="Krish Patil" 
              className="w-full h-full object-cover"
            />
          </div>
          <h3 className="text-3xl font-bold mb-4 text-white">Connect Directly</h3>
          <p className="text-slate-400 mb-10 text-lg leading-relaxed">Prefer email? Shoot me a message and I'll get back to you within 24 hours.</p>
          <button 
            type="button"
            className="justify-center w-full py-4 text-lg rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 hover:border-amber-500/50 transition-all flex items-center gap-2 text-white font-bold" 
            onClick={() => window.location.href = 'mailto:krrishp447@gmail.com'}
          >
            Email Me <ExternalLink size={20} />
          </button>
          <div className="mt-6 text-slate-500 text-sm font-mono tracking-wider">krrishp447@gmail.com</div>
        </SpotlightCard>
      </div>
    </motion.div>
  </div>
);

// --- MAIN APP ---

export default function Portfolio() {
  const [activeView, setActiveView] = useState('home');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);

  useEffect(() => {
    const handleMouseMove = (e) => {
      mouseX.set(e.clientX);
      mouseY.set(e.clientY);
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [mouseX, mouseY]);

  // CMS State
  const [isAdmin, setIsAdmin] = useState(false);
  const [showAdminModal, setShowAdminModal] = useState(false);
  const [cmsData, setCmsData] = useState({ metrics: [], services: [], portfolio: [], experience: [] });
  const [user, setUser] = useState(null);

  // Auth Effect (only if Firebase is configured)
  useEffect(() => {
    if (!isFirebaseReady || !auth) return;

    const unsubscribe = onAuthStateChanged(auth, (u) => setUser(u));

    const initAuth = async () => {
      try {
        if (typeof window !== 'undefined' && window.__initial_auth_token) {
          await signInWithCustomToken(auth, window.__initial_auth_token);
        } else {
          await signInAnonymously(auth);
        }
      } catch (error) {
        console.error("Auth failed:", error);
      }
    };
    
    initAuth();
    return () => unsubscribe();
  }, []);

  // Data Fetch Effect
  useEffect(() => {
    const initData = async () => {
      // DEMO MODE: use defaults
      if (!isFirebaseReady || !db) {
        setCmsData(DEFAULTS);
        setLoading(false);
        return;
      }

      // If using Firebase, wait until auth gives us a user
      if (!user) return;

      try {
        const newCmsData = { ...cmsData };
        for (const key of ['metrics', 'services', 'portfolio', 'experience']) {
          const colRef = collection(db, 'artifacts', appId, 'public', 'data', key);
          const snap = await getDocs(colRef);
          if (snap.empty) {
            const seededData = await Promise.all(
              DEFAULTS[key].map(async (item) => {
                const docRef = await addDoc(colRef, item);
                return { ...item, id: docRef.id };
              })
            );
            newCmsData[key] = seededData;
          } else {
            newCmsData[key] = snap.docs.map(d => ({ id: d.id, ...d.data() }));
          }
        }
        setCmsData(newCmsData);
      } catch (e) {
        console.error("Init error:", e);
        setCmsData(DEFAULTS);
      } finally {
        setLoading(false);
      }
    };
    initData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  // CRUD Logic
  const handleCmsUpdate = async (collectionName, item, action) => {
    if (!isFirebaseReady || !db) {
      alert("CMS features are disabled in Demo Mode.");
      return;
    }
    try {
      const colRef = collection(db, 'artifacts', appId, 'public', 'data', collectionName);
      let newData = [...cmsData[collectionName]];

      if (action === 'add') {
        const docRef = await addDoc(colRef, item);
        newData.push({ ...item, id: docRef.id });
      } else if (action === 'update') {
        const { id, ...data } = item;
        await updateDoc(doc(colRef, id), data);
        newData = newData.map(d => d.id === id ? item : d);
      } else if (action === 'delete') {
        await deleteDoc(doc(colRef, item.id));
        newData = newData.filter(d => d.id !== item.id);
      }
      
      setCmsData(prev => ({ ...prev, [collectionName]: newData }));
    } catch (e) {
      console.error("Update error:", e);
      alert("Operation failed. Check console.");
    }
  };

  const handleAdminLogin = (pin) => {
    if (pin === '1234') {
      setIsAdmin(true);
      setShowAdminModal(false);
      setActiveView('dashboard');
    } else {
      alert('Incorrect PIN');
    }
  };

  const navLinks = [...NAV_LINKS];
  if (isAdmin) navLinks.push({ id: 'dashboard', label: 'Dashboard' });

  const viewportWidth = typeof window !== 'undefined' ? window.innerWidth : 1200;
  const viewportHeight = typeof window !== 'undefined' ? window.innerHeight : 800;

  const bgX = useTransform(mouseX, [0, viewportWidth], [20, -20]);
  const bgY = useTransform(mouseY, [0, viewportHeight], [20, -20]);
  const gridX = useTransform(mouseX, [0, viewportWidth], [-50, 50]);
  const gridY = useTransform(mouseY, [0, viewportHeight], [50, 150]);

  return (
    <div className="bg-slate-950 min-h-screen text-slate-50 font-sans selection:bg-amber-500/30 selection:text-amber-100 relative overflow-x-hidden perspective-1000">
      <AnimatePresence>
        {loading && <LoadingScreen onComplete={() => setLoading(false)} />}
      </AnimatePresence>
      
      <AnimatePresence>
        {isContactModalOpen && (
          <ContactModal isOpen={isContactModalOpen} onClose={() => setIsContactModalOpen(false)} />
        )}
      </AnimatePresence>

      {/* Background */}
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden bg-slate-950 perspective-1000">
        <motion.div style={{ x: bgX, y: bgY }} className="absolute inset-0">
          <div className="absolute top-[-10%] left-[20%] w-[500px] h-[500px] bg-indigo-600/20 rounded-full mix-blend-multiply filter blur-[100px] opacity-30 animate-blob" />
          <div className="absolute top-[20%] right-[10%] w-[500px] h-[500px] bg-amber-600/20 rounded-full mix-blend-multiply filter blur-[100px] opacity-30 animate-blob animation-delay-2000" />
          <div className="absolute bottom-[-10%] left-[30%] w-[600px] h-[600px] bg-pink-600/20 rounded-full mix-blend-multiply filter blur-[100px] opacity-30 animate-blob animation-delay-4000" />
        </motion.div>
        
        {/* 3D Cyber Grid */}
        <motion.div 
          style={{ 
            rotateX: 60, 
            x: gridX, 
            y: gridY 
          }} 
          className="absolute inset-[-100%] w-[300%] h-[300%] opacity-30 pointer-events-none"
        >
          <div 
            className="absolute inset-0 w-full h-full"
            style={{
              backgroundImage: `
                linear-gradient(rgba(255, 255, 255, 0.08) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.08) 1px, transparent 1px)
              `,
              backgroundSize: '100px 100px',
              maskImage: 'linear-gradient(to bottom, transparent 5%, black 40%, black 70%, transparent 95%)'
            }}
          />
          <div 
            className="absolute inset-0 w-full h-full"
            style={{
              backgroundImage: `
                linear-gradient(rgba(255, 255, 255, 0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.03) 1px, transparent 1px)
              `,
              backgroundSize: '20px 20px',
              maskImage: 'linear-gradient(to bottom, transparent 5%, black 40%, black 70%, transparent 95%)'
            }}
          />
        </motion.div>

        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 brightness-100 contrast-150"></div>
      </div>

      {!loading && (
        <>
          {/* Navigation */}
          <motion.nav initial={{ y: -100 }} animate={{ y: 0 }} className="fixed top-6 left-0 right-0 z-50 flex justify-center px-4">
            <div className="w-full max-w-4xl bg-slate-900/70 backdrop-blur-2xl border border-white/10 rounded-full px-2 py-2 flex items-center justify-between shadow-2xl hover:border-white/20 transition-all duration-300">
              <div
                className="pl-6 text-xl font-extrabold tracking-tighter cursor-pointer flex items-center gap-2"
                onClick={() => setActiveView('home')}
              >
                Krish<span className="text-amber-500">.</span>
              </div>
              <div className="hidden md:flex items-center bg-slate-950/50 rounded-full p-1 border border-white/5">
                {navLinks.map(link => (
                  <SpotlightButton key={link.id} onClick={() => setActiveView(link.id)} isActive={activeView === link.id}>
                    {link.label}
                  </SpotlightButton>
                ))}
              </div>
              <div className="hidden md:block pr-2">
                {isAdmin ? (
                  <button
                    type="button"
                    onClick={() => { setIsAdmin(false); setActiveView('home'); }}
                    className="bg-slate-800 text-slate-300 font-bold px-6 py-2.5 rounded-full text-sm hover:text-white"
                  >
                    <LogOut size={16} />
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => setIsContactModalOpen(true)}
                    className="bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold px-6 py-2.5 rounded-full shadow-lg shadow-amber-500/20 text-sm"
                  >
                    Get in Touch
                  </button>
                )}
              </div>
              <div className="pr-2 md:hidden">
                <button
                  type="button"
                  className="p-3 bg-slate-800 text-white rounded-full hover:bg-slate-700 border border-white/10"
                  onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                >
                  {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
                </button>
              </div>
            </div>
          </motion.nav>

          {/* Mobile Menu */}
          <AnimatePresence>
            {isMobileMenuOpen && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="fixed top-[72px] left-0 right-0 z-40 px-4 md:hidden"
              >
                <div className="max-w-4xl mx-auto bg-slate-900/90 backdrop-blur-2xl border border-white/10 rounded-3xl p-4 flex flex-col gap-2">
                  {navLinks.map(link => (
                    <button
                      key={link.id}
                      type="button"
                      onClick={() => {
                        setActiveView(link.id);
                        setIsMobileMenuOpen(false);
                      }}
                      className={`w-full text-left px-4 py-3 rounded-2xl text-sm font-semibold ${
                        activeView === link.id
                          ? 'bg-white text-slate-900'
                          : 'text-slate-200 hover:bg-slate-800'
                      }`}
                    >
                      {link.label}
                    </button>
                  ))}
                  {!isAdmin && (
                    <button
                      type="button"
                      onClick={() => {
                        setIsContactModalOpen(true);
                        setIsMobileMenuOpen(false);
                      }}
                      className="w-full mt-2 px-4 py-3 rounded-2xl bg-amber-500 text-slate-900 font-bold text-sm"
                    >
                      Get in Touch
                    </button>
                  )}
                  {!isAdmin && (
                    <button
                      type="button"
                      onClick={() => {
                        setShowAdminModal(true);
                        setIsMobileMenuOpen(false);
                      }}
                      className="w-full mt-1 px-4 py-3 rounded-2xl text-slate-500 text-xs flex items-center justify-center gap-1"
                    >
                      <Lock size={14} /> Admin
                    </button>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Main Content */}
          <main className="min-h-screen relative z-10 pt-24">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeView}
                initial={{ opacity: 0, filter: "blur(10px)", y: 20 }}
                animate={{ opacity: 1, filter: "blur(0px)", y: 0 }}
                exit={{ opacity: 0, filter: "blur(10px)", y: -20 }}
                transition={{ duration: 0.4, ease: "easeOut" }}
              >
                {activeView === 'home' && (
                  <HomeView
                    setView={setActiveView}
                    onLetsTalk={() => setIsContactModalOpen(true)}
                    metrics={cmsData.metrics}
                    mouseX={mouseX}
                    mouseY={mouseY}
                  />
                )}
                {activeView === 'services' && (
                  <ServicesView services={cmsData.services} experience={cmsData.experience} />
                )}
                {activeView === 'work' && <WorkView portfolio={cmsData.portfolio} />}
                {activeView === 'ai-demo' && <AIToolView />}
                {activeView === 'contact' && <ContactView />}
                {activeView === 'dashboard' && isAdmin && (
                  <div className="pt-32 pb-24 max-w-7xl mx-auto px-6 min-h-screen">
                    <h1 className="text-5xl font-bold mb-12 text-white">CMS Dashboard</h1>
                    <Dashboard title="Portfolio Items" collectionName="portfolio" data={cmsData.portfolio} onUpdate={handleCmsUpdate} />
                    <Dashboard title="Services" collectionName="services" data={cmsData.services} onUpdate={handleCmsUpdate} />
                    <Dashboard title="Experience" collectionName="experience" data={cmsData.experience} onUpdate={handleCmsUpdate} />
                    <Dashboard title="Metrics" collectionName="metrics" data={cmsData.metrics} onUpdate={handleCmsUpdate} />
                  </div>
                )}
              </motion.div>
            </AnimatePresence>
          </main>

          {/* Footer */}
          <footer className="relative z-10 border-t border-white/5 py-12 bg-slate-950/50 backdrop-blur-lg">
            <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6 text-slate-500 text-sm font-medium">
              <div>© 2025 Krish Patil. Mumbai, India.</div>
              <div className="flex gap-8 items-center">
                <a href="https://www.linkedin.com/in/krrish-patil-8619a9275/" target="_blank" rel="noopener noreferrer" className="hover:text-amber-500 transition-colors"><Linkedin size={18} /></a>
                <a href="#" className="hover:text-amber-500 transition-colors"><Instagram size={18} /></a>
                <a href="#" className="hover:text-amber-500 transition-colors"><Youtube size={18} /></a>
                <a href="mailto:krrishp447@gmail.com" className="hover:text-amber-500 transition-colors"><Mail size={18} /></a>
                {!isAdmin && (
                  <button
                    type="button"
                    onClick={() => setShowAdminModal(true)}
                    className="text-slate-700 hover:text-amber-500 transition-colors"
                  >
                    <Lock size={14} />
                  </button>
                )}
              </div>
            </div>
          </footer>

          {/* Admin Modal */}
          <AdminLoginModal
            isOpen={showAdminModal}
            onClose={() => setShowAdminModal(false)}
            onLogin={handleAdminLogin}
          />
        </>
      )}
    </div>
  );
}
